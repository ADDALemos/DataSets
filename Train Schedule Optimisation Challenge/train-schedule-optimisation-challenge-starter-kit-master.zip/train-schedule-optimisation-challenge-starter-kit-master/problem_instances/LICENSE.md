Copyright 2018 Schweizerische Bundesbahnen SBB CFF FFS

The data files in this folder were made available as part of the Train Schedule Optimisation Challenge on crowdAI.com.

Terms and conditions of use for the data files in this folder are the same as those governing the provision of data defined as open data from SBB AG, as defined at https://data.sbb.ch/page/licence/