Description of data for paper titled:

	"Considering passenger and operator inconvenience in the scheduling of large railway projects"

by MP Kidd, RM Lusby and J Larsen.


What is called "sections" in the data refers to what is called "infrastructure resources" in the paper.
What is called "routes" in the data refers to what is called "critical sets" in the paper.


Each instance file contains the following data:

------------------------------------------------------
instance_name:	[instance ID]
class_name:	[class ID]
horizon:	[horizon length]
break_tol:	[]*
activities:
[id]	[duration]	[resource consumption]	[earliest start time]	[latest start time]	[section occupied]
sections:
[id]	[priority]*
routes:
[priority]	[section]	[section]	...
coordinations:
[activity]	[activity]	[min time lag]	[max time lag]
conflicts:
[activity]	[activity]
------------------------------------------------------

*not considered in this work
